package fiap.com.br.Pdima.ProjetoMercado.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import fiap.com.br.Pdima.ProjetoMercado.model.Personagem;
import fiap.com.br.Pdima.ProjetoMercado.repository.PersonagemRepository;

@Service
public class PersonagemService {
    private final PersonagemRepository repo;

    public PersonagemService(PersonagemRepository repo) {
        this.repo = repo;
    }

    public List<Personagem> listar() {
        return repo.findAll();
    }

    public Optional<Personagem> buscar(Long id) {
        return repo.findById(id);
    }

    public Personagem salvar(Personagem p) {
        return repo.save(p);
    }

    public void deletar(Long id) {
        repo.deleteById(id);
    }

    public List<Personagem> buscarPorNome(String nome) {
        return repo.findByNomeContainingIgnoreCase(nome);
    }

    public List<Personagem> buscarPorClasse(String classe) {
        return repo.findByClasse(classe);
    }
}