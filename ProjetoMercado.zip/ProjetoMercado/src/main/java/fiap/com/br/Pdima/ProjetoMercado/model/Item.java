package fiap.com.br.Pdima.ProjetoMercado.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@Entity
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String nome;

    @Pattern(regexp = "arma|armadura|poção|acessório", message = "Tipo inválido")
    private String tipo;

    @Pattern(regexp = "comum|raro|épico|lendário", message = "Raridade inválida")
    private String raridade;

    @Min(0)
    private int preco;

    @ManyToOne
    private Personagem dono;

    // Getters e setters
}