package fiap.com.br.Pdima.ProjetoMercado.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import fiap.com.br.Pdima.ProjetoMercado.model.Personagem;
import fiap.com.br.Pdima.ProjetoMercado.service.PersonagemService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/personagens")
public class PersonagemController {
    private final PersonagemService service;

    public PersonagemController(PersonagemService service) {
        this.service = service;
    }

    @GetMapping
    public List<Personagem> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Personagem> buscar(@PathVariable Long id) {
        return service.buscar(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Personagem> criar(@RequestBody @Valid Personagem p) {
        return ResponseEntity.ok(service.salvar(p));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Personagem> atualizar(@PathVariable Long id, @RequestBody @Valid Personagem novo) {
        return service.buscar(id).map(p -> {
            novo.setId(id);
            return ResponseEntity.ok(service.salvar(novo));
        })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (service.buscar(id).isPresent()) {
            service.deletar(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/buscar")
    public List<Personagem> buscarPorNome(@RequestParam(required = false) String nome,
            @RequestParam(required = false) String classe) {
        if (nome != null)
            return service.buscarPorNome(nome);
        if (classe != null)
            return service.buscarPorClasse(classe);
        return service.listar();
    }
}