package fiap.com.br.Pdima.ProjetoMercado.service;

import java.util.List;

import fiap.com.br.Pdima.ProjetoMercado.model.Item;

public class ItemService {

    public List<Item> listar() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'listar'");
    }

    public Object buscar(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'buscar'");
    }

}
