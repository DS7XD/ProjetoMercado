package fiap.com.br.Pdima.ProjetoMercado.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@Entity
public class Personagem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String nome;

    @Pattern(regexp = "guerreiro|mago|arqueiro", message = "Classe inválida")
    private String classe;

    @Min(1)
    @Max(99)
    private int nivel;

    @Min(0)
    private int moedas;

    // Getters e setters
}