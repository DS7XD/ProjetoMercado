package fiap.com.br.Pdima.ProjetoMercado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoMercadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoMercadoApplication.class, args);
	}

}
