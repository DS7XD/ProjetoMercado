package fiap.com.br.Pdima.ProjetoMercado.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import fiap.com.br.Pdima.ProjetoMercado.model.Personagem;

@Repository
public interface PersonagemRepository extends JpaRepository<Personagem, Long> {
    List<Personagem> findByNomeContainingIgnoreCase(String nome);

    List<Personagem> findByClasse(String classe);
}