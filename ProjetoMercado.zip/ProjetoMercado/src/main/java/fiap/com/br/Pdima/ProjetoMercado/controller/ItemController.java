package fiap.com.br.Pdima.ProjetoMercado.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import fiap.com.br.Pdima.ProjetoMercado.model.Item;
import fiap.com.br.Pdima.ProjetoMercado.service.ItemService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/itens")
public class ItemController {
    private final ItemService service;

    public ItemController(ItemService service) {
        this.service = service;
    }

    @GetMapping
    public List<Item> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Item> buscar(@PathVariable Long id) {
        return ((Object) service.buscar(id)).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Item> criar(@RequestBody @Valid Item i) {
        return ResponseEntity.ok(service.salvar(i));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Item> atualizar(@PathVariable Long id, @RequestBody @Valid Item novo) {
        return service.buscar(id).map(i -> {
            novo.setId(id);
            return ResponseEntity.ok(service.salvar(novo));
        })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (service.buscar(id).isPresent()) {
            service.deletar(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/buscar")
    public List<Item> buscar(
            @RequestParam(required = false) String nome,
            @RequestParam(required = false) String tipo,
            @RequestParam(required = false) String raridade,
            @RequestParam(required = false) Integer precoMin,
            @RequestParam(required = false) Integer precoMax) {

        if (nome != null)
            return service.buscarPorNome(nome);
        if (tipo != null)
            return service.buscarPorTipo(tipo);
        if (raridade != null)
            return service.buscarPorRaridade(raridade);
        if (precoMin != null && precoMax != null)
            return service.buscarPorPrecoEntre(precoMin, precoMax);
        return service.listar();
    }
}