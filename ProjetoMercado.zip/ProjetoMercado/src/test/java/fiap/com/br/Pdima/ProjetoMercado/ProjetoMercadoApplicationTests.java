package fiap.com.br.Pdima.ProjetoMercado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoMercadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
