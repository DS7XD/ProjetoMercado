package br.com.fiap.money_control_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoneyControlApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
