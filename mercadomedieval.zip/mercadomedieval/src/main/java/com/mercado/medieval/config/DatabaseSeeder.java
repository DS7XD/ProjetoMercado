package com.mercado.medieval.config;

import org.springframework.stereotype.Component;

import com.mercadomedieval.model.Item;
import com.mercadomedieval.model.Personagem;
import com.mercadomedieval.repository.ItemRepository;
import com.mercadomedieval.repository.PersonagemRepository;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class DatabaseSeeder {

        private final PersonagemRepository personagemRepository;
        private final ItemRepository itemRepository;

        @PostConstruct
        public void seed() {
                if (personagemRepository.count() == 0) {
                        Personagem mago = personagemRepository.save(
                                        new Personagem(null, "Merlin", Personagem.Classe.MAGO, 45, 1500));

                        Personagem guerreiro = personagemRepository.save(
                                        new Personagem(null, "Thorgar", Personagem.Classe.GUERREIRO, 60, 2300));

                        itemRepository.save(new Item(null, "Espada Flamejante", Item.Tipo.ARMA, Item.Raridade.EPICO,
                                        800, guerreiro));
                        itemRepository.save(new Item(null, "Elixir da Invisibilidade", Item.Tipo.POCAO,
                                        Item.Raridade.RARO, 500, mago));
                }
        }
}
