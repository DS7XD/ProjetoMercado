package com.mercado.medieval.specification;

import org.springframework.data.jpa.domain.Specification;

import com.mercadomedieval.model.Item;

public class ItemSpecification {

    public static Specification<Item> nomeContem(String nome) {
        return (root, query, cb) -> nome == null ? null
                : cb.like(cb.lower(root.get("nome")), "%" + nome.toLowerCase() + "%");
    }

    public static Specification<Item> tipoIgual(Item.Tipo tipo) {
        return (root, query, cb) -> tipo == null ? null : cb.equal(root.get("tipo"), tipo);
    }

    public static Specification<Item> raridadeIgual(Item.Raridade raridade) {
        return (root, query, cb) -> raridade == null ? null : cb.equal(root.get("raridade"), raridade);
    }

    public static Specification<Item> precoEntre(Double min, Double max) {
        return (root, query, cb) -> {
            if (min != null && max != null)
                return cb.between(root.get("preco"), min, max);
            if (min != null)
                return cb.greaterThanOrEqualTo(root.get("preco"), min);
            if (max != null)
                return cb.lessThanOrEqualTo(root.get("preco"), max);
            return null;
        };
    }
}
