package com.mercadomedieval.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/itens")
public class ItemController {

    private final ItemRepository repository;

    public ItemController(ItemRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Item> listar() {
        return repository.findAll();
    }

    @PostMapping
    public Item criar(@RequestBody Item item) {
        return repository.save(item);
    }

    @GetMapping("/buscar")
    public List<Item> buscarPorNome(@RequestParam String nome) {
        return repository.findByNomeContainingIgnoreCase(nome);
    }

    @GetMapping("/tipo")
    public List<Item> buscarPorTipo(@RequestParam Item.Tipo tipo) {
        return repository.findByTipo(tipo);
    }

    @GetMapping("/preco")
    public List<Item> buscarPorPrecoEntre(@RequestParam double min, @RequestParam double max) {
        return repository.findByPrecoBetween(min, max);
    }

    @GetMapping("/raridade")
    public List<Item> buscarPorRaridade(@RequestParam Item.Raridade raridade) {
        return repository.findByRaridade(raridade);
    }
}
