package com.mercadomedieval.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mercadomedieval.model.Personagem;
import com.mercadomedieval.repository.PersonagemRepository;

@RestController
@RequestMapping("/personagens")
public class PersonagemController {

    private final PersonagemRepository repository;

    public PersonagemController(PersonagemRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Personagem> listar() {
        return repository.findAll();
    }

    @PostMapping
    public Personagem criar(@RequestBody Personagem personagem) {
        return repository.save(personagem);
    }

    @GetMapping("/buscar")
    public List<Personagem> buscarPorNome(@RequestParam String nome) {
        return repository.findByNomeContainingIgnoreCase(nome);
    }

    @GetMapping("/classe")
    public List<Personagem> buscarPorClasse(@RequestParam Personagem.Classe classe) {
        return repository.findByClasse(classe);
    }
}
