package com.mercadomedieval.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PersonagemRepository extends JpaRepository<Personagem, Long> {
    List<Personagem> findByNomeContainingIgnoreCase(String nome);

    List<Personagem> findByClasse(Personagem.Classe classe);
}
