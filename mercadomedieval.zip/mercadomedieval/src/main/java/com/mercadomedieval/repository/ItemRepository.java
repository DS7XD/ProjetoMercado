package com.mercadomedieval.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemRepository extends JpaRepository<Item, Long> {
    List<Item> findByNomeContainingIgnoreCase(String nome);

    List<Item> findByTipo(Tipo tipo);

    List<Item> findByPrecoBetween(double minimo, double maximo);

    List<Item> findByRaridade(Raridade raridade);
}
